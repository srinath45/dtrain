﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            div_dropdow.Visible = false;
            div_menuoptions.Visible = false;
        }
        else
        {
            div_dropdow.Visible = true;
            div_menuoptions.Visible = true;
            if (Convert.ToString(Session["EmailID"]) == "raju@mm.com")
            {
                href_MessagesCount.Visible = true;
            }
        }
    }

    protected void href_SpamMails_ServerClick(object sender, EventArgs e)
    {
        Session["Group"] = null;
        Session["Group"] = "Spam";
        Response.Redirect("Dashboard.aspx");
    }

    protected void href_Priority_ServerClick(object sender, EventArgs e)
    {
        Session["Group"] = null;
        Session["Group"] = "Priority";
        Response.Redirect("Dashboard.aspx");
    }

    protected void href_Archieve_ServerClick(object sender, EventArgs e)
    {
        Session["Group"] = null;
        Session["Group"] = "Archieve";
        Response.Redirect("Dashboard.aspx");
    }

    protected void href_Trash_ServerClick(object sender, EventArgs e)
    {
        Session["Group"] = null;
        Session["Group"] = "Trash";
        Response.Redirect("Dashboard.aspx");
    }

    protected void href_Inbox_ServerClick(object sender, EventArgs e)
    {
        Session["Group"] = null;
        Session["Group"] = "Inbox";
        Response.Redirect("Dashboard.aspx");
    }
}
