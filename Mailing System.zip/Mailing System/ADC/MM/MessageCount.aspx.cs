﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MessageCount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                SqlCommand command1 = new SqlCommand("get_sentMessagesCount", connection);
                SqlCommand command2 = new SqlCommand("get_recievedMessagesCount", connection);
                command1.CommandType = CommandType.StoredProcedure;
                command2.CommandType = CommandType.StoredProcedure;
                connection.Open();
                DataTable table1 = new DataTable();
                DataTable table2 = new DataTable();
                table1.Load(command1.ExecuteReader());
                table2.Load(command2.ExecuteReader());
                ds1.Tables.Add(table1);
                ds2.Tables.Add(table2);
                connection.Close();

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    dataGrid1.DataSource = ds1;
                    dataGrid1.DataBind();
                    dataGrid1.Visible = true;
                    Fail.Visible = false;
                }
                else
                {
                    dataGrid1.Visible = false;
                    Fail.Visible = true;
                }
                if (ds2.Tables[0].Rows.Count > 0)
                {
                    dataGrid2.DataSource = ds2;
                    dataGrid2.DataBind();
                    dataGrid2.Visible = true;
                    Fail.Visible = false;
                }
                else
                {
                    dataGrid2.Visible = false;
                    Fail.Visible = true;
                }
            }
            catch (Exception exs)
            { }
        }
    }
}