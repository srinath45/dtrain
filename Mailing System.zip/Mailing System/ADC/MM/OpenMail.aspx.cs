﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class OpenMail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Sigin.aspx");
        }
        if (!Page.IsPostBack)
        {
            DataSet ds;
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter("select reciever, subject, description from tbl_MailsTOandFro where transid="+Convert.ToInt32(Session["MailTransID"]), conn))
                    {
                        da.SelectCommand.CommandType = CommandType.Text;
                        ds = new DataSet();
                        da.Fill(ds);
                    }
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    EmailID.Text = ds.Tables[0].Rows[0][0].ToString();
                    subject.Text = ds.Tables[0].Rows[0][1].ToString();
                    desc.Text = ds.Tables[0].Rows[0][2].ToString();
                }

            }
            catch (Exception exs)
            { }


        }
    }

    protected void UpdateGroup_Click(object sender, EventArgs e)
    {
        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand da = new SqlCommand("update tbl_MailsTOandFro set groupid='" + ddl_ChangeGroup.SelectedValue + "' where transid='" + Convert.ToInt32(Session["MailTransID"]) + "'", conn))
                {
                    da.CommandType = CommandType.Text;
                    conn.Open();
                    da.ExecuteNonQuery();
                    conn.Close();
                }
            }
            success.Visible = true;
        }
        catch (Exception ex)
        { }
    }
}