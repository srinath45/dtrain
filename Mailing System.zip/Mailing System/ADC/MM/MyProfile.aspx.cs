﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Sigin.aspx");
        }
        DataSet ds;
        string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select * from tbl_UserData where emailid='" + Convert.ToString(Session["EmailID"]) + "'", conn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                EmailID.Text = ds.Tables[0].Rows[0][0].ToString();
                password.Text = ds.Tables[0].Rows[0][1].ToString();
                FName.Text = ds.Tables[0].Rows[0][2].ToString();
                LName.Text = ds.Tables[0].Rows[0][3].ToString();
                txt_Sex.Text = ds.Tables[0].Rows[0][4].ToString();
                MobileNumber.Text = ds.Tables[0].Rows[0][5].ToString();
                RMailID.Text = ds.Tables[0].Rows[0][6].ToString();
                SecQues.Text = ds.Tables[0].Rows[0][8].ToString();
                SecANs.Text = ds.Tables[0].Rows[0][9].ToString();
            }
            else
            {
                Response.Redirect("dashboard.aspx");
            }

        }
        catch (Exception exs)
        { }
    }
}