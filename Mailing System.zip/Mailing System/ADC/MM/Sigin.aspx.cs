﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sigin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] != null)
        {
            Response.Redirect("Dashboard.aspx");
        }
    }

    protected void btn_SignIn_Click(object sender, EventArgs e)
    {
        DataSet ds;
        string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select emailid from tbl_UserData where emailid='" + EmailID.Text+"' and password='"+password.Text+"'", conn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand da = new SqlCommand("insert into tbl_LoginHistory values ('"+EmailID.Text+"','"+DateTime.Now+"','121.12.122.122')", conn))
                    {
                        da.CommandType = CommandType.Text;
                        conn.Open();
                        da.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                Session["EmailID"] = ds.Tables[0].Rows[0]["emailid"].ToString();
                LoginFail.Visible = false;
                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                LoginFail.Visible = true;
            }

        }
        catch (Exception exs)
        { }
    }
}