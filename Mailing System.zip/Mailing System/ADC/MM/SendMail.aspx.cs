﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SendMail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Sigin.aspx");
        }

    }

    protected void Send_Click(object sender, EventArgs e)
    {
        DataSet ds;
        string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select emailid from tbl_UserData where emailid='" + EmailID.Text + "'", conn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand da = new SqlCommand("insert into tbl_MailsTOandFro values ('" + Convert.ToString(Session["EmailID"]) + "','" + EmailID.Text + "','" + subject.Text + "','" + desc.Text + "','1','" + DateTime.Now + "','Inbox',(select count(*)+1 from tbl_MailsTOandFro))", conn))
                    {
                        da.CommandType = CommandType.Text;
                        conn.Open();
                        da.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                fail.Visible = false;
                success.Visible = true;
                EmailID.Text = "";
                subject.Text = "";
                desc.Text = "";
            }
            else
            {
                fail.Visible = true;
                success.Visible = false;
            }

        }
        catch (Exception exs)
        { }

      
    }
}