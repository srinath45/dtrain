﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        EmailID.Text = Convert.ToString(Session["EmailID"]);
    }

    protected void btn_Update_Click(object sender, EventArgs e)
    {
        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand da = new SqlCommand("insert into tbl_PasswordChangeHistory values ('"+Convert.ToString(Session["EmailID"])+"','"+ password.Text + "','"+password.Text+"','"+DateTime.Now+"')", conn))
                {
                    da.CommandType = CommandType.Text;
                    conn.Open();
                    da.ExecuteNonQuery();
                    conn.Close();
                }
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand da = new SqlCommand("update tbl_UserData set password ='" + password.Text+"' where emailid='"+Convert.ToString(Session["EmailID"])+"'", conn))
                {
                    da.CommandType = CommandType.Text;
                    conn.Open();
                    da.ExecuteNonQuery();
                    conn.Close();
                }
            }
            Session["EmailID"] = EmailID.Text;
            Response.Redirect("Dashboard.aspx");
        }
        catch (Exception ex)
        { }
    }
}